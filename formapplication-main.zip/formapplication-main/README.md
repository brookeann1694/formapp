# Dream Harvest Data Collection Forms

## Includes the following forms:

**Daily Yield Form**

  *This form is designed to collect usable, waste and any other yield or information collected from daily harvesting*


**Ellepot Batch Form**

  *This form is designed to collect incoming ellepot data from ellepot shipments*
  

**Transplant Form**

  *This form is designed to collect data on seedlings transplanted into mature trays on the data of transplant*
  

**Mature Tray Observations Form**

**

**System Adjustment Form**

**

**System Cleaning/Adjustment Form**

**





etc...etc....

